const ShiftJSONs=[

// Roushan Kumar    
	{
		associate: 'Roushan Kumar',
		day: 1,
		shift: 'A'
	},
	
		{
		associate: 'Roushan Kumar',
		day: 2,
		shift: 'A'
	},
    {
		associate: 'Roushan Kumar',
		day: 3,
		shift: 'W'
	},
    {
		associate: 'Roushan Kumar',
		day: 5,
		shift: 'G'
	},
    {
		associate: 'Roushan Kumar',
		day: 6,
		shift: 'A'
	},
    {
		associate: 'Roushan Kumar',
		day: 7,
		shift: 'SD'
	},
    {
		associate: 'Roushan Kumar',
		day: 8,
		shift: 'A'
	},
    {
		associate: 'Roushan Kumar',
		day: 9,
		shift: 'A'
	},
    {
		associate: 'Roushan Kumar',
		day: 12,
		shift: 'SD'
	},
    {
		associate: 'Roushan Kumar',
		day: 13,
		shift: 'L'
	},
    {
		associate: 'Roushan Kumar',
		day: 14,
		shift: 'L'
	},
    {
		associate: 'Roushan Kumar',
		day: 15,
		shift: 'A'
	},
    {
		associate: 'Roushan Kumar',
		day: 16,
		shift: 'EM'
	},
    {
		associate: 'Roushan Kumar',
		day: 19,
		shift: 'A'
	},
    {
		associate: 'Roushan Kumar',
		day: 20,
		shift: 'A'
	},
    {
		associate: 'Roushan Kumar',
		day: 21,
		shift: 'G'
	},
    {
		associate: 'Roushan Kumar',
		day: 22,
		shift: 'M'
	},
    {
		associate: 'Roushan Kumar',
		day: 23,
		shift: 'G'
	},
    {
		associate: 'Roushan Kumar',
		day: 26,
		shift: 'EM'
	},
    {
		associate: 'Roushan Kumar',
		day: 27,
		shift: 'A'
	},
    {
		associate: 'Roushan Kumar',
		day: 28,
		shift: 'M'
	},
    {
		associate: 'Roushan Kumar',
		day: 29,
		shift: 'G'
	},
    {
		associate: 'Roushan Kumar',
		day: 30,
		shift: 'A'
	},

// Ashima Singhal

    {
		associate: 'Ashima Singhal',
		day: 1,
		shift: 'EM'
	},
	
		{
		associate: 'Ashima Singhal',
		day: 2,
		shift: 'EM'
	},
    {
		associate: 'Ashima Singhal',
		day: 3,
		shift: 'HS'
	},
    {
		associate: 'Ashima Singhal',
		day: 5,
		shift: 'G'
	},
    {
		associate: 'Ashima Singhal',
		day: 6,
		shift: 'S'
	},
    {
		associate: 'Ashima Singhal',
		day: 7,
		shift: 'L'
	},
    {
		associate: 'Ashima Singhal',
		day: 8,
		shift: 'L'
	},
    {
		associate: 'Ashima Singhal',
		day: 9,
		shift: 'G'
	},
    {
		associate: 'Ashima Singhal',
		day: 12,
		shift: 'A'
	},
    {
		associate: 'Ashima Singhal',
		day: 13,
		shift: 'L'
	},
    {
		associate: 'Ashima Singhal',
		day: 14,
		shift: 'L'
	},
    {
		associate: 'Ashima Singhal',
		day: 15,
		shift: 'L'
	},
    {
		associate: 'Ashima Singhal',
		day: 16,
		shift: 'A'
	},
    {
		associate: 'Ashima Singhal',
		day: 19,
		shift: 'SD'
	},
    {
		associate: 'Ashima Singhal',
		day: 20,
		shift: 'G'
	},
    {
		associate: 'Ashima Singhal',
		day: 21,
		shift: 'M'
	},
    {
		associate: 'Ashima Singhal',
		day: 22,
		shift: 'EM'
	},
    {
		associate: 'Ashima Singhal',
		day: 23,
		shift: 'S'
	},
    {
		associate: 'Ashima Singhal',
		day: 24,
		shift: 'W'
	},
    {
		associate: 'Ashima Singhal',
		day: 26,
		shift: 'G'
	},
    {
		associate: 'Ashima Singhal',
		day: 27,
		shift: 'EM'
	},
    {
		associate: 'Ashima Singhal',
		day: 28,
		shift: 'EM'
	},
    {
		associate: 'Ashima Singhal',
		day: 29,
		shift: 'A'
	},
    {
		associate: 'Ashima Singhal',
		day: 30,
		shift: 'G'
    },


// Princy Katlana
    {
		associate: 'Princy Katlana',
		day: 1,
		shift: 'EM'
	},
	
		{
		associate: 'Princy Katlana',
		day: 2,
		shift: 'L'
	},
    {
		associate: 'Princy Katlana',
		day: 5,
		shift: 'L'
	},
    {
		associate: 'Princy Katlana',
		day: 6,
		shift: 'G'
	},
    {
		associate: 'Princy Katlana',
		day: 7,
		shift: 'SD'
	},
    {
		associate: 'Princy Katlana',
		day: 8,
		shift: 'G'
	},
    {
		associate: 'Princy Katlana',
		day: 9,
		shift: 'EM'
	},
    {
		associate: 'Princy Katlana',
		day: 12,
		shift: 'M'
	},
    {
		associate: 'Princy Katlana',
		day: 13,
		shift: 'L'
	},
    {
		associate: 'Princy Katlana',
		day: 14,
		shift: 'A'
	},
    {
		associate: 'Princy Katlana',
		day: 15,
		shift: 'S'
	},
    {
		associate: 'Princy Katlana',
		day: 16,
		shift: 'M'
	},
    {
		associate: 'Princy Katlana',
		day: 19,
		shift: 'G'
	},
    {
		associate: 'Princy Katlana',
		day: 20,
		shift: 'S'
	},
    {
		associate: 'Princy Katlana',
		day: 21,
		shift: 'EM'
	},
    {
		associate: 'Princy Katlana',
		day: 22,
		shift: 'EM'
	},
    {
		associate: 'Princy Katlana',
		day: 23,
		shift: 'M'
	},
    {
		associate: 'Princy Katlana',
		day: 26,
		shift: 'M'
	},
    {
		associate: 'Princy Katlana',
		day: 27,
		shift: 'G'
	},
    {
		associate: 'Princy Katlana',
		day: 28,
		shift: 'EM'
	},
    {
		associate: 'Princy Katlana',
		day: 29,
		shift: 'A'
	},
    {
		associate: 'Princy Katlana',
		day: 30,
		shift: 'G'
    },

// Shantanu Singh

{
    associate: 'Shantanu Singh',
    day: 1,
    shift: 'EM'
},

    {
    associate: 'Shantanu Singh',
    day: 2,
    shift: 'A'
},
{
    associate: 'Shantanu Singh',
    day: 3,
    shift: 'W'
},
{
    associate: 'Shantanu Singh',
    day: 5,
    shift: 'G'
},
{
    associate: 'Shantanu Singh',
    day: 6,
    shift: 'G'
},
{
    associate: 'Shantanu Singh',
    day: 7,
    shift: 'EM'
},
{
    associate: 'Shantanu Singh',
    day: 8,
    shift: 'L'
},
{
    associate: 'Shantanu Singh',
    day: 9,
    shift: 'L'
},
{
    associate: 'Shantanu Singh',
    day: 12,
    shift: 'SD'
},
{
    associate: 'Shantanu Singh',
    day: 13,
    shift: 'EM'
},
{
    associate: 'Shantanu Singh',
    day: 14,
    shift: 'L'
},
{
    associate: 'Shantanu Singh',
    day: 15,
    shift: 'G'
},
{
    associate: 'Shantanu Singh',
    day: 16,
    shift: 'S'
},
{
    associate: 'Shantanu Singh',
    day: 17,
    shift: 'W'
},
{
    associate: 'Shantanu Singh',
    day: 19,
    shift: 'EM'
},
{
    associate: 'Shantanu Singh',
    day: 20,
    shift: 'G'
},
{
    associate: 'Shantanu Singh',
    day: 21,
    shift: 'A'
},
{
    associate: 'Shantanu Singh',
    day: 22,
    shift: 'L'
},
{
    associate: 'Shantanu Singh',
    day: 23,
    shift: 'A'
},
{
    associate: 'Shantanu Singh',
    day: 26,
    shift: 'EM'
},
{
    associate: 'Shantanu Singh',
    day: 27,
    shift: 'A'
},
{
    associate: 'Shantanu Singh',
    day: 28,
    shift: 'M'
},
{
    associate: 'Shantanu Singh',
    day: 29,
    shift: 'G'
},
{
    associate: 'Shantanu Singh',
    day: 30,
    shift: 'A'
},
	
//Urja Rajpara

{
    associate: 'Urja Rajpara',
    day: 1,
    shift: 'G'
},

    {
    associate: 'Urja Rajpara',
    day: 2,
    shift: 'EM'
},
{
    associate: 'Urja Rajpara',
    day: 3,
    shift: 'W'
},
{
    associate: 'Urja Rajpara',
    day: 5,
    shift: 'S'
},
{
    associate: 'Urja Rajpara',
    day: 6,
    shift: 'S'
},
{
    associate: 'Urja Rajpara',
    day: 7,
    shift: 'SD'
},
{
    associate: 'Urja Rajpara',
    day: 8,
    shift: 'L'
},
{
    associate: 'Urja Rajpara',
    day: 9,
    shift: 'L'
},
{
    associate: 'Urja Rajpara',
    day: 10,
    shift: 'W'
},
{
    associate: 'Urja Rajpara',
    day: 11,
    shift: 'W'
},
{
    associate: 'Urja Rajpara',
    day: 12,
    shift: 'G'
},
{
    associate: 'Urja Rajpara',
    day: 13,
    shift: 'A'
},
{
    associate: 'Urja Rajpara',
    day: 14,
    shift: 'A'
},
{
    associate: 'Urja Rajpara',
    day: 15,
    shift: 'G'
},
{
    associate: 'Urja Rajpara',
    day: 16,
    shift: 'L'
},
{
    associate: 'Urja Rajpara',
    day: 19,
    shift: 'EM'
},
{
    associate: 'Urja Rajpara',
    day: 20,
    shift: 'M'
},
{
    associate: 'Urja Rajpara',
    day: 21,
    shift: 'S'
},
{
    associate: 'Urja Rajpara',
    day: 22,
    shift: 'EM'
},
{
    associate: 'Urja Rajpara',
    day: 23,
    shift: 'A'
},
{
    associate: 'Urja Rajpara',
    day: 26,
    shift: 'L'
},
{
    associate: 'Urja Rajpara',
    day: 27,
    shift: 'G'
},
{
    associate: 'Urja Rajpara',
    day: 28,
    shift: 'EM'
},
{
    associate: 'Urja Rajpara',
    day: 29,
    shift: 'L'
},
{
    associate: 'Urja Rajpara',
    day: 30,
    shift: 'L'
}
]

export default ShiftJSONs;